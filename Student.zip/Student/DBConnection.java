package overridingComparable;

import java.sql.Connection;
import java.sql.DriverManager;
//import com.mysql.jdbc.Statement;
public class DBConnection {
	static Connection conn = null;
	
	public static Connection connectWithDB(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/optum","root","admin");
			//java.sql.Statement stmt = conn.createStatement();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
