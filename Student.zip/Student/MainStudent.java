package overridingComparable;

import java.util.Scanner;

public class MainStudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDAO sdao = new StudentDAO();
		Scanner sc = new Scanner(System.in);
		do{
			System.out.println("1. Display all Students");
			System.out.println("2. Insert a Student");
			System.out.println("3. Update marks by Student ID");
			System.out.println("4. Delete student where Marks is less than 40");
			System.out.println("5. Sort Students and Display");
			System.out.println("0. Exit");
			char ch = sc.next().charAt(0);
			switch(ch){
				case '1': sdao.displayStudent();
						break;
				case '2': sdao.insertStudent();
						break;
				case '3': sdao.updateStudent();
						break;
				case '4': sdao.deleteStudent();
						break;
				case '5': sdao.sortStudent();
						break;
				case '0': System.exit(0);
						break;
				default: System.out.println("Invalid Option..!! Please Try Again.");
			}
		}while(true);
		//sc.close();
			
	}

}
