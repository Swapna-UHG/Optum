package overridingComparable;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentDAO{
	public static Connection connDAO = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static PreparedStatement ps = null;
	public static final ArrayList<Student> studentList = new ArrayList<Student>(); 

	public void createStmtDB(){
		try {
			connDAO = DBConnection.connectWithDB();
			stmt = connDAO.createStatement();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void displayStudent(){
		try {
			//System.out.println(connDAO);
			createStmtDB();
			//System.out.println(connDAO);

			rs = stmt.executeQuery("select * from student");
			while(rs.next()){
				Student stud = new Student();
				stud.setSid(rs.getString("sid"));
				stud.setSname(rs.getString("sname"));
				stud.setMarks(rs.getInt("marks"));
				studentList.add(stud);
			}
			display();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void display(){
		if(studentList.size()==0){
			System.out.println("No Student Record Found.");
		}
		else{
			for(int i=0;i<studentList.size();i++){
				System.out.print(studentList.get(i).getSid()+"\t\t");
				System.out.print(studentList.get(i).getSname()+"\t\t");
				System.out.println(studentList.get(i).getMarks());
			}
		}
		
	}
	
	public void insertStudent(){
		try{
			createStmtDB();
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter Student ID : ");
			String sid12 = sc.nextLine();
			System.out.println("Enter Student Name : ");
			String sname = sc.nextLine();
			System.out.println("Enter Student Marks : ");
			int marks = sc.nextInt();
			ps = connDAO.prepareStatement("insert into student values(?,?,?)");
			if(connDAO==null)
				System.out.println("null");
			ps.setString(1, sid12);
			ps.setString(2, sname);
			ps.setInt(3, marks);
			int i = ps.executeUpdate();
			if(i!=0)System.out.println("Student Record inserted");
			//sc.close();
			display();
		}catch(Exception E){
			E.printStackTrace();
		}
	}
	
	public void updateStudent(){
		try{
			createStmtDB();
			System.out.println("Enter Student ID :");
			Scanner sc = new Scanner(System.in);
			String sid = sc.next();
			System.out.println("Enter New Marks : ");
			int marks = sc.nextInt();
			ps = connDAO.prepareStatement("update student set marks=? where sid=?;");
			ps.setInt(1, marks);
			ps.setString(2, sid);
			int i = ps.executeUpdate();
			if(i!=0)System.out.println("Student Record updated.");
			//sc.close();
			display();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void deleteStudent(){
		try{
			createStmtDB();
			ps = connDAO.prepareStatement("delete from student where marks<40;");
			int i = ps.executeUpdate();
			if(i!=0)System.out.println("Student Record deleted where marks is less than 40.");
			display();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void sortStudent() {
		// TODO Auto-generated method stub
		Collections.sort(studentList);
		display();
	}
}
