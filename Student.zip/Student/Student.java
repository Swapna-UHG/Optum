package overridingComparable;

import java.util.Objects;

public class Student implements Comparable<Student>{
	private String sid;
	private String sname;
	private int marks;
	
	public Student(String sid, String sname, int marks){
		this.sid = sid;
		this.sname = sname;
		this.marks = marks;
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	@Override
	public int compareTo(Student stud) {
		// TODO Auto-generated method stub
		return this.getMarks() - stud.getMarks();
	}
	
	@Override
	public int hashCode(){
		return Objects.hash(marks);
	}
	@Override
	public boolean equals(Object obj){
		if(this == obj) return true;
		if(obj == null ||getClass()!=obj.getClass()) return false;
		Student studobj = (Student) obj;
		return marks == studobj.marks;
	}
	@Override
	public String toString(){
		return "Student{"+"id="+sid+", name='"+sname+"\'"+"}";
	}
	
}
