package studentProject;
import java.util.*;
public class Mains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("1. insert 2. update 3. delete 4. show students 5. exit");
Scanner obj = new Scanner(System.in);
int i  = obj.nextInt();
switch(i){
case 1 : {
    new StudentDAO().insertData();
    break;
}
case 2 : {
	new StudentDAO().update();
	break;
}
case 3 :{
	new StudentDAO().Delete();
	break;
}
case 4 :{
	new StudentDAO().fetchData();
	break;
}
default:{System.exit(0);
break;}


}
	}

}
