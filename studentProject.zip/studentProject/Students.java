package studentProject;

import java.util.Objects;

import comparableDemo.Customer;

public class Students  implements Comparable<Students>{
	private int id;
	private String name;
	private double marks;
	
	
public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getMarks() {
		return marks;
	}
	public void setMarks(double marks) {
		this.marks = marks;
	}
	
	
	@Override
	public int compareTo(Students as) {
		// TODO Auto-generated method stub
		return (int) (this.getMarks() - as.getMarks());
	}	
	@Override
	public int hashCode(){
		
	   return Objects.hash(marks);
	}

	public boolean equals(Object obj){
		if(this==obj) return true;
		if((obj==null)||getClass()!=obj.getClass()) return false;
		Students stobj = (Students) obj;
		
		return marks == stobj.marks;
		
	}
	public String toString(){
		
		return "Student{"+"id= "+id+",name= "+name+" marks= "+marks+"}\n";
		
		
	}
}
