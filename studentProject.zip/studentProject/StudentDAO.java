package studentProject;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
import collectionWithDB.DBConnection;
import comparableDemo.Customer;
import productsProject.products;

public class StudentDAO{
	public static Connection conDAO =null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	Scanner obj = new Scanner(System.in);
	
	
	public void insertData(){
		try{
		conDAO = DBConnection.connectWithDB();
		stmt = conDAO.createStatement();
		int count=0;
		do{
			System.out.println("Enter ID \n");
		int id = obj.nextInt();
		System.out.println("Enter Name \n");
		String sname = obj.next();
		System.out.println("Enter Marks \n");
		double marks =  obj.nextDouble();
		stmt.executeUpdate("insert into studentProject values("+id+",'"+sname+"',"+marks+")");
		System.out.println("Do you want to enter more! 1. yes 0. no");
		count = obj.nextInt();
		}
		while(count!=0);
		
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void Delete(){
	try{
		conDAO = DBConnection.connectWithDB();
		stmt = conDAO.createStatement();
		
		stmt.executeUpdate("delete from studentProject where marks<40");
			}
	catch(Exception e){
		e.printStackTrace();
	}
		
	}
	
	public void update(){
		try{
			conDAO = DBConnection.connectWithDB();
			stmt = conDAO.createStatement();
			int count=0;
			do{
			System.out.println("Enter the ID you want to update!");
			int id_u = obj.nextInt();
			System.out.println("Enter new marks");
			double mark = obj.nextDouble();
			
			stmt.executeUpdate("update studentProject SET marks="+mark+"where sid="+id_u+";");
			System.out.println("Do you want to update more. 1. yes 0. no");
			count = obj.nextInt();
		}
		while(count!=0);
			}
		
		
		catch(Exception e){
			e.printStackTrace();
		}
			
	}
	
	
	public void fetchData(){
		
		try{
			conDAO = DBConnection.connectWithDB();
			stmt = conDAO.createStatement();
			rs = stmt.executeQuery("select * from studentProject");
			Delete();

			ArrayList<Students> students = new ArrayList<Students>();

					while(rs.next()){
						Students objstudent = new Students();
						objstudent.setId(rs.getInt("sid"));
						objstudent.setName(rs.getString("sname"));
						objstudent.setMarks(rs.getDouble("marks"));
					    students.add(objstudent);						
					}
					
					for(int i=0;i<students.size();i++){
System.out.println(students.get(i).getId()+" "+students.get(i).getName()+" "+students.get(i).getMarks());
					}
					
					System.out.println("Sorted \n");
					Collections.sort(students);
					System.out.println(students);
					
						
		}
				
				catch(Exception e){e.printStackTrace();}

		
		
	}

	
}
