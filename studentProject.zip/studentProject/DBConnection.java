package studentProject;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	 static Connection con;
	 
	 
		public static Connection connectWithDB(){
			try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/optum_uhg","root","admin");
			
			//establish connection

			if(con == null){
				System.out.println("connection not established");
			}
			}
			
			catch(Exception e){
				e.printStackTrace();
				}
			
			return con;
			
		}
}
