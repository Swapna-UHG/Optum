package javaapplication;

import java.sql.*;

public class DataDAO {
	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static ResultSet createStmtDB(){
		try{
		con = DBConnection.connectWithDB();
		stmt = con.createStatement();
		rs= stmt.executeQuery("select * from persons");
		}
		catch(Exception e){
			System.out.println(e);
		}
		return rs;
	}

}
