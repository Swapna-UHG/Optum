package javaapplication;

public class Person {
	private String name;
	private String jobtitle;
	private int freqflyer;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public int getFreqflyer() {
		return freqflyer;
	}
	public void setFreqflyer(int freqflyer) {
		this.freqflyer = freqflyer;
	}
	

}
