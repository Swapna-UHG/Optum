package javaapplication;

import java.sql.ResultSet;
import java.util.ArrayList;

public class MainPerson {
	public static ResultSet rs = null;

	public static void main(String[] args) {
       try{
    	   rs = DataDAO.createStmtDB();
    	   ArrayList<Person>personlist = new  ArrayList<Person>();
    	   while(rs.next()){
    		   Person objperson = new Person();
    		   objperson.setName(rs.getString("name"));
    		   objperson.setJobtitle(rs.getString("jobtitle"));
    		   objperson.setFreqflyer(rs.getInt("frqflyer"));
    		   personlist.add(objperson);
    		   
    	   }
    	   System.out.println(personlist.size());
    	   for(int i = 0; i<personlist.size();i++){
    		   System.out.println(personlist.get(i).getName()+"\t");
    		   System.out.println(personlist.get(i).getJobtitle()+"\t");
    		   System.out.println();
    	   }
       }
       catch(Exception e){
    	   System.out.println(e);
       }
	
	
	}

}
