package stud;

import java.util.Objects;

public class Student implements Comparable<Student>{
	private Integer sid;
	private String sname;
	private Integer marks;
	public Integer getSid() {
		return sid;
	}
	public void setSid(Integer sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public Integer getMarks() {
		return marks;
	}
	public void setMarks(Integer marks) {
		this.marks = marks;
	}
	public int compareTo(Student st){
		return this.getMarks().compareTo(st.getMarks());
	}
	public int hashCode(){
		return Objects.hash(marks);
	}
	public boolean equals(Object obj){
		if(this==obj)
			return true;
		if(obj==null || getClass() !=obj.getClass())
			return false;
		Student st = (Student) obj;
		return marks== st.marks;
			
	}
	/*public int compareTo(Object arg0){
		return 0;
	}*/
	public String toString(){
		return "Student{" + "sid="+sid+", name= "+ sname+ ",marks= "+ marks + "}" ;
	}
	
	
	
	
	
	

}
