package stud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DBConnection {
	static Connection con = null;
	public static Connection connectWithDB() {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con= DriverManager.getConnection("jdbc:mysql://localhost:3306/optum_uhg","root","admin");
		Statement stmt = con.createStatement();
		
		
		}
		catch(Exception e){
			
		}
		
		if(con == null)
			{
			System.out.println("nooo");
			return con;
			}
		else
		return con;
	}

}
