package stud;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainStudent {

	public static void main(String[] args) {
		StudentDAO.fetch();
		System.out.println("insert");
		StudentDAO.insertstd();
		StudentDAO.fetch();
		System.out.println("update");
		StudentDAO.updatestd();
		StudentDAO.fetch();
		System.out.println("delete");
		StudentDAO.delectstd();
		StudentDAO.fetch();
		List<Student> slists = new ArrayList<Student>();
				slists = StudentDAO.fetch();
				System.out.println(slists);
		Collections.sort(slists);
		System.out.println(slists);// TODO Auto-generated method stub

	}

}
