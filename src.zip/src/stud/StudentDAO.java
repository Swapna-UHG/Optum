package stud;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javaapplication.DBConnection;
import javaapplication.DataDAO;
import javaapplication.Person;

public class StudentDAO {
	public static Connection con = null;
	public static Statement stmt = null;
	public static ResultSet rs = null;
	public static ResultSet createStmtDB(){
		try{
		con = DBConnection.connectWithDB();
		stmt = con.createStatement();
		rs= stmt.executeQuery("select * from students");
		}
		catch(Exception e){
			System.out.println(e);
		}
		return rs;
	}
	static int i;
	public static int insertstd(){
		try{
		i=stmt.executeUpdate("insert into students values(4,'monu',20)");
		}
		catch(Exception e){
		 System.out.println(e);
		}
		return i;
	}
	static int d;
	public static int delectstd(){
		try{
			d= stmt.executeUpdate("delete from students where marks<40");
			
		} catch(Exception e){
			System.out.println(e);
		}
		return d;
		}
		static int u;
		public static int updatestd(){
			try{
				u=stmt.executeUpdate("update students set marks=100 where sid=2");
			}catch(Exception e){
				System.out.println(e);
			}
			return u;
		}
		public static ArrayList<Student> fetch(){
			ArrayList<Student> stdlist = new  ArrayList<Student>();
			try{
		    	   rs = StudentDAO.createStmtDB();
		    	   
		    	   while(rs.next()){
		    		   Student objperson = new Student();
		    		   objperson.setSid(rs.getInt("sid"));
		    		   objperson.setSname(rs.getString("sname"));
		    		   objperson.setMarks(rs.getInt("marks"));
		    		   stdlist.add(objperson);
		    		   
		    	   }
		    	   System.out.println(stdlist.size());
		    	   for(int i = 0; i<stdlist.size();i++){
		    		   System.out.println(stdlist.get(i).getSid()+"\t");
		    		   System.out.println(stdlist.get(i).getSname()+"\t");
		    		   System.out.println(stdlist.get(i).getMarks()+"\t");
		    		   System.out.println();
		    	   }
		       }
		       catch(Exception e){
		    	   System.out.println(e);
		       }
			return stdlist;

		}
		
		
		
		
		
		
		
		
		
		
	}



