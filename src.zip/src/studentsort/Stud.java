package studentsort;

import java.util.Objects;

public class Stud implements Comparable<Stud>
{
private int sid;
private String sname;
private  int marks;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getMarks() {
	return marks;
}
public void setMarks(int marks) {
	this.marks = marks;
}
public Stud(int sid,String sname, int marks)
{
	this.sid = sid;
	this.sname = sname;
	this.marks = marks;
}
public int compareTo(Stud stdobj){
	return this.getMarks() - stdobj.getMarks();
	//return this.getCname().compareTo(custobj.getCname());
}
public int hashcode()
{
	return Objects.hash(marks);
	
}
public boolean equals(Object obj){
	if(this == obj) return true;
    if(obj == null || getClass()!=obj.getClass()) return false;
    Stud stdobj = (Stud) obj;
    return marks == stdobj.marks;
}

public String toString()
{
	return "Stud{"+"id="+ sid +", name='"+ sname+", marks='"+marks+'\''+'}';

}}
