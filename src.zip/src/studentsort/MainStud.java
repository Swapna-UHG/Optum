package studentsort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class MainStud {
	public static void main(String args[])
	{
		Stud st1= new Stud(01,"akshansh",80);
		Stud st= new Stud(02,"akansh",60);
		Stud st2= new Stud(03,"arti",40);

		
		List<Stud> stdlst=new ArrayList<Stud>();
		stdlst.add(st);
		stdlst.add(st1);
		stdlst.add(st2);

		
		System.out.println("customers before sorting"+stdlst);
		Collections.sort(stdlst);
		System.out.println("customers after sorting"+stdlst);

		
	}
	}

