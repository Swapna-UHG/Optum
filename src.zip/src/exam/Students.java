package exam;

import java.util.Objects;

public class Students implements Comparable<Students> {
	private int sid;
	private String sname;
	private int marks;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}


public int compareTo(Students studobj){
	return this.getMarks()-studobj.getMarks();
}
public int hashCode()
{
	return Objects.hash(marks);
		
	
}
public boolean equals(Object obj){
	if(this==obj)return true;
	if(obj==null||getClass()!=obj.getClass())
	return false;
			Students custobj=(Students)obj;
	return marks==custobj.marks;
	
}

public String toString(){
	return "Students{"+"sid="+sid
+"marks="+marks+"name="+sname+'\''+'}';
}


}


