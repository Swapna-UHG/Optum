package exam;
import java.sql.ResultSet;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Scanner;

import java.util.ArrayList;
public class MainStudents 
{
	
	/**
	 * @param args
	 */
	public static ResultSet rs=null;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter 1or 2or3or4");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		switch(n)
		{
		
		
		case 1:DataDAO.displayStudentDB();
		 break;
		case 2:
			DataDAO.insertstudentDB();
			break;
			
		case 3:
			DataDAO.updatestudentDB();
			break;
			
		case 4: DataDAO.deletestudentDB();
			break;
		}
		System.out.println("sorted order is\n");
		List<Students>slist=new ArrayList<Students>();
		slist=DataDAO.fetchDataDB();
		Collections.sort(slist);
		System.out.println(slist);
}
}


