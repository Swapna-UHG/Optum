package exam;
import java.sql.*;
import java.util.ArrayList;

public class DataDAO {
	public static Connection connDAO=null;
	public static Statement stmt=null;
	public static ResultSet rs=null;
	public static ResultSet displayStudentDB(){
		try{
			
		connDAO=DBConnection.connectWithDB();
		stmt=connDAO.createStatement();
		rs=stmt.executeQuery("select * from students");
	}
	catch(Exception e)
	{
	e.printStackTrace(); 
		
	}
	return rs;
	}
	static int i;
	public static int insertstudentDB()
	{
		try
		{
			connDAO=DBConnection.connectWithDB();
			stmt=connDAO.createStatement();
			i=stmt.executeUpdate("insert into students values(01,'shiva',60),(02,'ganesha',32),(03,'krishna',38),(04,'madhav',50)");
			}
		catch(Exception e)
		{
		e.printStackTrace(); 
			
		}
		return i;
	}
	
	static int j;
	public static int updatestudentDB()
	{
		try
		{
			connDAO=DBConnection.connectWithDB();
			stmt=connDAO.createStatement();
			j=stmt.executeUpdate("update table students set sid=05 where marks=60");
			
		}
		catch(Exception e)
		{
		e.printStackTrace(); 
			
		}
		return j;
	}
	
	static int k;
	public static int deletestudentDB()
	{
		try
		{
			connDAO=DBConnection.connectWithDB();
			stmt=connDAO.createStatement();
			k=stmt.executeUpdate("delete from students where marks<40");
			
		}
		catch(Exception e)
		{
		e.printStackTrace(); 
			
		}
		return k;
	}
	
		
	
		public static ArrayList<Students> fetchDataDB(){
			ArrayList<Students> Studentslist =new ArrayList<Students>();
	try{
		rs=DataDAO.displayStudentDB();
		//i=DataDAO.insertstudentDB();
		//j=DataDAO.updatestudentDB();
		//k=DataDAO.deletestudentDB();
		
				while(rs.next()){
					Students objstud=new Students();
					objstud.setSid(rs.getInt("sid"));
					objstud.setSname(rs.getString("sname"));
					objstud.setMarks(rs.getInt("marks"));
					Studentslist.add(objstud);
				}
				//System.out.println(Studentslist.size());
		for(int i=0;i<Studentslist.size();i++){
			System.out.println(Studentslist.get(i).getSid()+"\t");
			System.out.println(Studentslist.get(i).getSname()+"\t");
			System.out.println(Studentslist.get(i).getMarks()+"\t");
			System.out.println();
		}

		

	}
		catch(Exception e)
		{
		e.printStackTrace(); 
			
		}
	return Studentslist;

}
	}