package exam;
import java.sql.*;

public class DBConnection {
	static Connection conn = null;
	public static Connection connectWithDB(){
		try{
			Class.forName("com.mysql.jdbc.Driver"); 
			  conn=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/optum_uhg","root","admin");
			//if(conn==null)
				//System.out.println("null");
			Statement stmt=conn.createStatement();
	}
		catch(Exception e)
		{
		e.printStackTrace(); 
			
		}
		return conn;
	}

}
 